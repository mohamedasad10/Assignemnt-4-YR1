import java.sql.Driver;
import java.util.Date;

public class RideRecord {
    protected Driver driver;

    //enum
    protected enum RideType{
        DUIKER,
        KUDU,
        TEMBO;
    }

    private Date date;
    private double fee;

    //Constructor
    public RideRecord(Driver driver, RideType type, double fee){
        this.driver = driver;
        this.fee = fee;
    }
}
