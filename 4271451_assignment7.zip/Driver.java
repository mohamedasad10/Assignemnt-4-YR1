import java.util.Date;

public class Driver extends Person {
    private String licenseCode;
    public Driver(String idNumber, String name, Date dateOfBirth, String licenseCode) {
        this.idNumber = idNumber;
        this.name = name;
        this.dateOfBirth = dateOfBirth;
        this.licenseCode = licenseCode;
    }

    @Override
    public int compareTo(Person p) {
        return 0;
    }
    public void giveRide(RideRecord.RideType type, double fee, Passenger passenger){

    }
}
