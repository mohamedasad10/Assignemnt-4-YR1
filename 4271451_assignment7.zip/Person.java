import java.util.Date;

public abstract class Person {
    protected String idNumber;
    protected Date dateOfBirth;
    protected String name;


    //Getter Methods
    public String getIdNumber() {
        return this.idNumber;
    }

    public Date getDateOfBirth() {
        return this.dateOfBirth;
    }

    public String getName() {
        return this.name;

    }
    //Default constructor
    public Person(){

    }


    //Constructor
    public Person(String idNumber, String name, Date dateOfBirth){
        this.idNumber = idNumber;
        this.name = name;
        this.dateOfBirth = dateOfBirth;

    }

    public abstract int compareTo(Person p);
}
