import java.util.ArrayList;
import java.util.Date;

public class Passenger extends Person{

    @Override
    public int compareTo(Person p) {
        return 0;
    }

    private ArrayList<RideRecord> rideHistory = new ArrayList<RideRecord>();

    public void takeRide(RideRecord rideRecord){
        rideHistory.add(rideRecord);
    }

    public boolean hasRideHistory( ){
        return true;
    }

    //Constructor
    public Passenger(String idNumber, String name, Date dateOfBirth){
        this.idNumber = idNumber;
        this.name = name;
        this.dateOfBirth = dateOfBirth;

    }
}
